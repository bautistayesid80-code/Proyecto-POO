/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ENTIDADES;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public class Facturas {
    private int id_factura;
    private String numero_factura;
    private Integer id_pedido;   // Integer permite valores null si la factura es independiente
    private int id_cliente;
    private int id_empleado;
    private LocalDateTime fecha_emision;
    private BigDecimal subtotal;
    private BigDecimal impuestos;
    private BigDecimal total;
    private String metodo_pago;
    private String estado_factura; // 'emitida', 'anulada', 'reembolsada'

    public Facturas() {
    }

    public Facturas(int id_factura, String numero_factura, Integer id_pedido, int id_cliente, 
                    int id_empleado, LocalDateTime fecha_emision, BigDecimal subtotal, 
                    BigDecimal impuestos, BigDecimal total, String metodo_pago, String estado_factura) {
        this.id_factura = id_factura;
        this.numero_factura = numero_factura;
        this.id_pedido = id_pedido;
        this.id_cliente = id_cliente;
        this.id_empleado = id_empleado;
        this.fecha_emision = fecha_emision;
        this.subtotal = subtotal;
        this.impuestos = impuestos;
        this.total = total;
        this.metodo_pago = metodo_pago;
        this.estado_factura = estado_factura;
    }

    public int getId_factura() { return id_factura; }
    public void setId_factura(int id_factura) { this.id_factura = id_factura; }

    public String getNumero_factura() { return numero_factura; }
    public void setNumero_factura(String numero_factura) { this.numero_factura = numero_factura; }

    public Integer getId_pedido() { return id_pedido; }
    public void setId_pedido(Integer id_pedido) { this.id_pedido = id_pedido; }

    public int getId_cliente() { return id_cliente; }
    public void setId_cliente(int id_cliente) { this.id_cliente = id_cliente; }

    public int getId_empleado() { return id_empleado; }
    public void setId_empleado(int id_empleado) { this.id_empleado = id_empleado; }

    public LocalDateTime getFecha_emision() { return fecha_emision; }
    public void setFecha_emision(LocalDateTime fecha_emision) { this.fecha_emision = fecha_emision; }

    public BigDecimal getSubtotal() { return subtotal; }
    public void setSubtotal(BigDecimal subtotal) { this.subtotal = subtotal; }

    public BigDecimal getImpuestos() { return impuestos; }
    public void setImpuestos(BigDecimal impuestos) { this.impuestos = impuestos; }

    public BigDecimal getTotal() { return total; }
    public void setTotal(BigDecimal total) { this.total = total; }

    public String getMetodo_pago() { return metodo_pago; }
    public void setMetodo_pago(String metodo_pago) { this.metodo_pago = metodo_pago; }

    public String getEstado_factura() { return estado_factura; }
    public void setEstado_factura(String estado_factura) { this.estado_factura = estado_factura; }
}