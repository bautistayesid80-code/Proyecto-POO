/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ENTIDADES;

/**
 *
 * @author prestamo
 */
import java.time.LocalDateTime;
import java.math.BigDecimal;

public class Facturas {
    private int id_factura;
    private String numero_factura;
    private int id_pedido;
    private int id_cliente;
    private int id_empleado;
    
    // Atributos para fecha y dinero
    private LocalDateTime fecha_emision;
    private BigDecimal subtotal;
    private BigDecimal impuestos;
    private BigDecimal total;
    
    private String metodo_pago;
    private String estado_factura;

    // Constructor vacío
    public Facturas() {
    }

    // Getters y Setters
    public LocalDateTime getFecha_emision() {
        return fecha_emision;
    }

    public void setFecha_emision(LocalDateTime fecha_emision) {
        this.fecha_emision = fecha_emision;
    }

    public BigDecimal getSubtotal() {
        return subtotal;
    }

    public void setSubtotal(BigDecimal subtotal) {
        this.subtotal = subtotal;
    }
}
