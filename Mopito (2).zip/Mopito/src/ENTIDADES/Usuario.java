/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ENTIDADES;

public class Usuario {
    private String id;              // varchar(36) UUID para "Código del usuario"
    private String nombre;          // first_name + last_name
    private String correo;          // email (Gmail del usuario)
    private String password;        // password_hash
    private String telefono;        // phone
    private String fechaRegistro;   // created_at ("Fecha de registro usuario")

    public Usuario() {}

    // Constructor completo
    public Usuario(String id, String nombre, String correo, String password, String telefono, String fechaRegistro) {
        this.id = id;
        this.nombre = nombre;
        this.correo = correo;
        this.password = password;
        this.telefono = telefono;
        this.fechaRegistro = fechaRegistro;
    }

    // Constructor para registro básico
    public Usuario(String nombre, String correo, String password) {
        this.nombre = nombre;
        this.correo = correo;
        this.password = password;
    }

    // Getters y Setters
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public String getCorreo() { return correo; }
    public void setCorreo(String correo) { this.correo = correo; }

    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }

    public String getTelefono() { return telefono; }
    public void setTelefono(String telefono) { this.telefono = telefono; }

    public String getFechaRegistro() { return fechaRegistro; }
    public void setFechaRegistro(String fechaRegistro) { this.fechaRegistro = fechaRegistro; }
}