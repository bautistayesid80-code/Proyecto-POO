/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ENTIDADES;

public class Facturas {
    private int idFactura;
    private String numeroFactura;
    private String codigoPedido;
    private String fechaEmision;
    private String userId;
    private String nombreUsuario;
    private String emailUsuario;
    private String telefonoUsuario;
    private String fechaRegistroUsuario;
    private String codigoComercio;
    private String nombreComercial;
    private double subtotal;
    private double iva;
    private double total;
    private String metodoPago;

    public Facturas() {}

    public Facturas(String numeroFactura, String codigoPedido, String fechaEmision, 
                    String userId, String nombreUsuario, String emailUsuario, 
                    String telefonoUsuario, String fechaRegistroUsuario, 
                    String codigoComercio, String nombreComercial, 
                    double subtotal, double iva, double total, String metodoPago) {
        this.numeroFactura = numeroFactura;
        this.codigoPedido = codigoPedido;
        this.fechaEmision = fechaEmision;
        this.userId = userId;
        this.nombreUsuario = nombreUsuario;
        this.emailUsuario = emailUsuario;
        this.telefonoUsuario = telefonoUsuario;
        this.fechaRegistroUsuario = fechaRegistroUsuario;
        this.codigoComercio = codigoComercio;
        this.nombreComercial = nombreComercial;
        this.subtotal = subtotal;
        this.iva = iva;
        this.total = total;
        this.metodoPago = metodoPago;
    }

    // Getters y Setters
    public int getIdFactura() { return idFactura; }
    public void setIdFactura(int idFactura) { this.idFactura = idFactura; }

    public String getNumeroFactura() { return numeroFactura; }
    public void setNumeroFactura(String numeroFactura) { this.numeroFactura = numeroFactura; }

    public String getCodigoPedido() { return codigoPedido; }
    public void setCodigoPedido(String codigoPedido) { this.codigoPedido = codigoPedido; }

    public String getFechaEmision() { return fechaEmision; }
    public void setFechaEmision(String fechaEmision) { this.fechaEmision = fechaEmision; }

    public String getUserId() { return userId; }
    public void setUserId(String userId) { this.userId = userId; }

    public String getNombreUsuario() { return nombreUsuario; }
    public void setNombreUsuario(String nombreUsuario) { this.nombreUsuario = nombreUsuario; }

    public String getEmailUsuario() { return emailUsuario; }
    public void setEmailUsuario(String emailUsuario) { this.emailUsuario = emailUsuario; }

    public String getTelefonoUsuario() { return telefonoUsuario; }
    public void setTelefonoUsuario(String telefonoUsuario) { this.telefonoUsuario = telefonoUsuario; }

    public String getFechaRegistroUsuario() { return fechaRegistroUsuario; }
    public void setFechaRegistroUsuario(String fechaRegistroUsuario) { this.fechaRegistroUsuario = fechaRegistroUsuario; }

    public String getCodigoComercio() { return codigoComercio; }
    public void setCodigoComercio(String codigoComercio) { this.codigoComercio = codigoComercio; }

    public String getNombreComercial() { return nombreComercial; }
    public void setNombreComercial(String nombreComercial) { this.nombreComercial = nombreComercial; }

    public double getSubtotal() { return subtotal; }
    public void setSubtotal(double subtotal) { this.subtotal = subtotal; }

    public double getIva() { return iva; }
    public void setIva(double iva) { this.iva = iva; }

    public double getTotal() { return total; }
    public void setTotal(double total) { this.total = total; }

    public String getMetodoPago() { return metodoPago; }
    public void setMetodoPago(String metodoPago) { this.metodoPago = metodoPago; }
}