package CONTROL;

import ENTIDADES.ItemPedido;
import java.util.ArrayList;
import java.util.List;

public class CarritoManager {

    private static CarritoManager instancia;
    private final List<ItemPedido> items;

    private CarritoManager() {
        this.items = new ArrayList<>();
    }

    public static synchronized CarritoManager getInstance() {
        if (instancia == null) {
            instancia = new CarritoManager();
        }
        return instancia;
    }

    // Agregar producto o sumar cantidad si ya existe
    public void agregarProducto(String nombre, int cantidad, double precioUnitario) {
        for (ItemPedido item : items) {
            if (item.getNombre().equalsIgnoreCase(nombre)) {
                // Si ya está en la lista, crea un nuevo registro sumando la cantidad
                int nuevaCantidad = item.getCantidad() + cantidad;
                items.remove(item);
                items.add(new ItemPedido(nombre, nuevaCantidad, precioUnitario));
                return;
            }
        }
        items.add(new ItemPedido(nombre, cantidad, precioUnitario));
    }

    public List<ItemPedido> getItems() {
        return new ArrayList<>(this.items);
    }

    public double calcularTotal() {
        double total = 0.0;
        for (ItemPedido item : items) {
            total += item.getSubtotal();
        }
        return total;
    }

    public int getCantidadTotalItems() {
        int count = 0;
        for (ItemPedido item : items) {
            count += item.getCantidad();
        }
        return count;
    }

    public void vaciarCarrito() {
        this.items.clear();
    }
}