/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CONTROL;

import ENTIDADES.Usuario;

public class SesionUsuario {
    private static SesionUsuario instance;
    private Usuario usuarioLogueado;

    private SesionUsuario() {}

    public static SesionUsuario getInstance() {
        if (instance == null) {
            instance = new SesionUsuario();
        }
        return instance;
    }

    public void iniciarSesion(Usuario usuario) {
        this.usuarioLogueado = usuario;
    }

    public Usuario getUsuarioLogueado() {
        return this.usuarioLogueado;
    }

    public void cerrarSesion() {
        this.usuarioLogueado = null;
    }

    public boolean estaLogueado() {
        return this.usuarioLogueado != null;
    }
    public boolean haySesionActiva() {
        return this.usuarioLogueado != null;
    }
}