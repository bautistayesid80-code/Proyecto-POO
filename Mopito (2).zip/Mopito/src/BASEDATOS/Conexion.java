/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package BASEDATOS;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class Conexion {
    // 1. Driver moderno CJ de MySQL
    private final String DRIVER = "com.mysql.cj.jdbc.Driver";
    
    // 2. Parámetros agregados al final de la URL
    private final String URL = "jdbc:mysql://localhost:3306/";
    private final String DB = "mokpito";
    private final String PARAMS = "?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC";
    
    private final String USER = "root";
    private final String PASSWORD = "";
    
    public Connection cadena;
    public static Conexion instancia;
    
    public Conexion() {
        this.cadena = null;
    }
    
    public Connection conectar() {
        try {
            Class.forName(DRIVER);
            this.cadena = DriverManager.getConnection(URL + DB + PARAMS, USER, PASSWORD);
        } catch (ClassNotFoundException | SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al conectar con la base de datos:\n" + e.getMessage(), 
                                          "Error de Conexión", JOptionPane.ERROR_MESSAGE);
            // Se quitó System.exit(0) para evitar que la ventana colapse en seco
        }
        return this.cadena;
    }
    
    public void desconectar() {
        try {
            if (this.cadena != null && !this.cadena.isClosed()) {
                this.cadena.close();
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al desconectar: " + e.getMessage());
        }
    }
    
    public synchronized static Conexion getInstancia() {
        if (instancia == null) {
            instancia = new Conexion();
        }
        return instancia;
    }
}

