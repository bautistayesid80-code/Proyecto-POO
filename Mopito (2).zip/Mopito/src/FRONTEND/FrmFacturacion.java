package FRONTEND;

import ENTIDADES.Facturas;
import ENTIDADES.ItemPedido;
import ENTIDADES.Usuario;
import DAO.FacturaDAO;
import CONTROL.CarritoManager;
import CONTROL.SesionUsuario;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.io.IOException;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;

public class FrmFacturacion extends javax.swing.JFrame {

    private String codigoPedidoRecibido;
    private List<ItemPedido> listaProductosRecibida;
    private double totalVentaCalculado = 0.0;
    private String metodoPagoRecibido = "Nequi";

    // Constructor sin parámetros
    public FrmFacturacion() {
        initComponents();
        this.setLocationRelativeTo(null);
        this.codigoPedidoRecibido = "PED-" + (int) (System.currentTimeMillis() % 10000);
        this.listaProductosRecibida = CarritoManager.getInstance().getItems();

        configurarEstiloEtiquetas();
        inicializarCamposFactura();
    }

    // Constructor que recibe pedido y productos desde CHECKOUT
    public FrmFacturacion(String codPedido, List<ItemPedido> productos) {
        initComponents();
        this.setLocationRelativeTo(null);
        this.codigoPedidoRecibido = codPedido;
        this.listaProductosRecibida = productos;

        configurarEstiloEtiquetas();
        inicializarCamposFactura();
    }

    // Constructor con los 4 parámetros (si CHECKOUT los envía)
    public FrmFacturacion(String codPedido, List<ItemPedido> productos, double totalFinal, String metodoPago) {
        initComponents();
        this.setLocationRelativeTo(null);
        this.codigoPedidoRecibido = codPedido;
        this.listaProductosRecibida = productos;
        this.totalVentaCalculado = totalFinal;
        this.metodoPagoRecibido = (metodoPago != null) ? metodoPago : "Nequi";

        configurarEstiloEtiquetas();
        inicializarCamposFactura();
    }

    private void exportarFacturaArchivo(ENTIDADES.Facturas f) {
        // Ventana para que el usuario elija la carpeta y nombre
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Guardar Factura");
        fileChooser.setSelectedFile(new File("Factura_" + f.getNumeroFactura() + ".txt"));

        int seleccion = fileChooser.showSaveDialog(this);

        if (seleccion == JFileChooser.APPROVE_OPTION) {
            File archivo = fileChooser.getSelectedFile();

            // Asegurar extensión .txt
            if (!archivo.getName().toLowerCase().endsWith(".txt")) {
                archivo = new File(archivo.getAbsolutePath() + ".txt");
            }

            try (PrintWriter writer = new PrintWriter(new FileWriter(archivo))) {
                writer.println("=================================================");
                writer.println("             MOKPO KOREAN CORN DOG              ");
                writer.println("               Comprobante Electrónico          ");
                writer.println("=================================================");
                writer.println("Factura N°:        " + f.getNumeroFactura());
                writer.println("Código Pedido:     " + f.getCodigoPedido());
                writer.println("Fecha de Emisión:  " + f.getFechaEmision());
                writer.println("Comercio:          " + f.getCodigoComercio() + " - " + f.getNombreComercial());
                writer.println("-------------------------------------------------");
                writer.println("DATOS DEL CLIENTE:");
                writer.println("ID / Documento:    " + f.getUserId());
                writer.println("Nombre:            " + f.getNombreUsuario());
                writer.println("Email:             " + f.getEmailUsuario());
                writer.println("Teléfono:          " + f.getTelefonoUsuario());
                writer.println("-------------------------------------------------");
                writer.println("DETALLE ECONÓMICO:");
                writer.println("Método de Pago:    " + f.getMetodoPago());
                writer.printf("Subtotal:          $%,.2f%n", f.getSubtotal());
                writer.printf("Impuestos / IVA:   $%,.2f%n", f.getIva());
                writer.printf("TOTAL PAGADO:      $%,.2f%n", f.getTotal());
                writer.println("=================================================");
                writer.println("        ¡Gracias por tu compra en Mokpo!        ");
                writer.println("=================================================");

                JOptionPane.showMessageDialog(this,
                        "Factura guardada exitosamente en:\n" + archivo.getAbsolutePath(),
                        "Factura Exportada",
                        JOptionPane.INFORMATION_MESSAGE);

            } catch (IOException ex) {
                JOptionPane.showMessageDialog(this,
                        "Error al escribir el archivo: " + ex.getMessage(),
                        "Error de Archivo",
                        JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void configurarEstiloEtiquetas() {
        java.awt.Font fuente = new java.awt.Font("Segoe UI", java.awt.Font.PLAIN, 12);
        java.awt.Color color = new java.awt.Color(60, 30, 30);

        javax.swing.JLabel[] etiquetas = {
            lblNumeroFactura, lblCodigoPedido, lblFechaEmision,
            lblNombreUsuario, lblEmailUsuario, lblTelefonoUsuario,
            lblFechaRegistroUsuario, lblCodigoComercio, lblNombreComercial
        };

        for (javax.swing.JLabel lbl : etiquetas) {
            if (lbl != null) {
                lbl.setFont(fuente);
                lbl.setForeground(color);
            }
        }

        if (lblCodigoUsuario != null) {
            lblCodigoUsuario.setFont(new java.awt.Font("Segoe UI", java.awt.Font.PLAIN, 10));
            lblCodigoUsuario.setForeground(color);
        }
    }

    private void inicializarCamposFactura() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        FacturaDAO dao = new FacturaDAO();

        // 1. Datos del Comercio
        lblCodigoComercio.setText("MKP-BOG-01");
        lblNombreComercial.setText("Mokpo Korean Corn Dog");

        // 2. Datos de Emisión y Pedido
        lblNumeroFactura.setText(dao.generarSiguienteNumeroFactura());
        lblCodigoPedido.setText(this.codigoPedidoRecibido);
        lblFechaEmision.setText(sdf.format(new Date()));

        // 3. Procesar el producto o lista de productos recibidos desde CHECKOUT
        StringBuilder detalleProductos = new StringBuilder();
        if (listaProductosRecibida != null && !listaProductosRecibida.isEmpty()) {
            for (ENTIDADES.ItemPedido item : listaProductosRecibida) {
                detalleProductos.append(item.getCantidad())
                        .append("x ")
                        .append(item.getNombre())
                        .append(" - $")
                        .append(String.format("%,.0f", item.getSubtotal()))
                        .append(" | ");
            }
            // Quitar el separador final
            if (detalleProductos.length() > 3) {
                detalleProductos.setLength(detalleProductos.length() - 3);
            }
        } else {
            detalleProductos.append("1x Half & Half - $12.900");
        }

        // Si cuentas con un JLabel para el producto/concepto en el diseño de FrmFacturacion:
        // lblDetalleProducto.setText(detalleProductos.toString());
        // 4. Datos del Usuario desde la sesión
        Usuario user = SesionUsuario.getInstance().getUsuarioLogueado();
        if (user != null) {
            lblCodigoUsuario.setText(user.getId());
            lblNombreUsuario.setText(user.getNombre());
            lblEmailUsuario.setText(user.getCorreo());
            lblTelefonoUsuario.setText(user.getTelefono() != null ? user.getTelefono() : "3001234567");
            lblFechaRegistroUsuario.setText(user.getFechaRegistro() != null ? user.getFechaRegistro() : "2026-10-20");
        } else {
            lblCodigoUsuario.setText("GUEST-001");
            lblNombreUsuario.setText("Cliente Mostrador");
            lblEmailUsuario.setText("cliente@mokpobites.com");
            lblTelefonoUsuario.setText("3000000000");
            lblFechaRegistroUsuario.setText("2026-11-10");
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        lblNumeroFactura = new javax.swing.JLabel();
        lblNombreUsuario = new javax.swing.JLabel();
        lblCodigoPedido = new javax.swing.JLabel();
        lblFechaEmision = new javax.swing.JLabel();
        lblEmailUsuario = new javax.swing.JLabel();
        lblCodigoUsuario = new javax.swing.JLabel();
        lblTelefonoUsuario = new javax.swing.JLabel();
        lblNombreComercial = new javax.swing.JLabel();
        lblFechaRegistroUsuario = new javax.swing.JLabel();
        lblCodigoComercio = new javax.swing.JLabel();
        btnGenerarFactura = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(249, 237, 221));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel1.add(lblNumeroFactura, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 190, 140, 30));
        jPanel1.add(lblNombreUsuario, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 400, 140, 30));
        jPanel1.add(lblCodigoPedido, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 250, 140, 20));
        jPanel1.add(lblFechaEmision, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 300, 140, 20));
        jPanel1.add(lblEmailUsuario, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 450, 140, 30));
        jPanel1.add(lblCodigoUsuario, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 350, 140, 20));
        jPanel1.add(lblTelefonoUsuario, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 500, 140, 20));
        jPanel1.add(lblNombreComercial, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 640, 140, 30));

        lblFechaRegistroUsuario.setToolTipText("");
        jPanel1.add(lblFechaRegistroUsuario, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 550, 140, 20));
        jPanel1.add(lblCodigoComercio, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 600, 140, 20));

        btnGenerarFactura.setBorderPainted(false);
        btnGenerarFactura.setContentAreaFilled(false);
        btnGenerarFactura.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGenerarFacturaActionPerformed(evt);
            }
        });
        jPanel1.add(btnGenerarFactura, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 683, 210, 50));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/Screenshot 2026-11-10 104006.png"))); // NOI18N
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnGenerarFacturaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGenerarFacturaActionPerformed

       Usuario user = SesionUsuario.getInstance().getUsuarioLogueado();
        String idUsuario = (user != null) ? user.getId() : lblCodigoUsuario.getText();
        String nomUsuario = (user != null) ? user.getNombre() : lblNombreUsuario.getText();
        String correoUsuario = (user != null) ? user.getCorreo() : lblEmailUsuario.getText();
        String telUsuario = (user != null) ? user.getTelefono() : lblTelefonoUsuario.getText();
        String fechaRegUsuario = (user != null) ? user.getFechaRegistro() : lblFechaRegistroUsuario.getText();

        double total = this.totalVentaCalculado;
        double subtotal = Math.round((total / 1.19) * 100.0) / 100.0;
        double iva = Math.round((total - subtotal) * 100.0) / 100.0;

        Facturas f = new Facturas(
                lblNumeroFactura.getText(),
                lblCodigoPedido.getText(),
                lblFechaEmision.getText(),
                idUsuario,
                nomUsuario,
                correoUsuario,
                telUsuario,
                fechaRegUsuario,
                lblCodigoComercio.getText(),
                lblNombreComercial.getText(),
                subtotal,
                iva,
                total,
                this.metodoPagoRecibido
        );

        FacturaDAO dao = new FacturaDAO();
        if (dao.guardarFactura(f)) {
            // 1. Vaciar el carrito tras compra exitosa
            CarritoManager.getInstance().vaciarCarrito();

            // 2. Notificación en pantalla
            JOptionPane.showMessageDialog(this,
                    "¡Factura #" + f.getNumeroFactura() + " guardada exitosamente en MySQL!\n"
                    + "Cliente: " + f.getNombreUsuario() + "\n"
                    + "Método de Pago: " + f.getMetodoPago() + "\n"
                    + "Total pagado: $" + String.format("%,.0f", f.getTotal()),
                    "Facturación Exitosa - Mokpo Bites",
                    JOptionPane.INFORMATION_MESSAGE);

            // 3. Exportar comprobante al disco del PC
            exportarFacturaArchivo(f);

            // 4. Cerrar la ventana de facturación
            this.dispose();
        } else {
            JOptionPane.showMessageDialog(this,
                    "Error al guardar la factura en la base de datos.",
                    "Error de Persistencia",
                    JOptionPane.ERROR_MESSAGE);
        }
  
    }//GEN-LAST:event_btnGenerarFacturaActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FrmFacturacion.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FrmFacturacion().setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnGenerarFactura;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel lblCodigoComercio;
    private javax.swing.JLabel lblCodigoPedido;
    private javax.swing.JLabel lblCodigoUsuario;
    private javax.swing.JLabel lblEmailUsuario;
    private javax.swing.JLabel lblFechaEmision;
    private javax.swing.JLabel lblFechaRegistroUsuario;
    private javax.swing.JLabel lblNombreComercial;
    private javax.swing.JLabel lblNombreUsuario;
    private javax.swing.JLabel lblNumeroFactura;
    private javax.swing.JLabel lblTelefonoUsuario;
    // End of variables declaration//GEN-END:variables
}
