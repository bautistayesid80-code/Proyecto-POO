package DAO;

import BASEDATOS.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class PedidoDAO {

    private final Conexion con;

    public PedidoDAO() {
        this.con = Conexion.getInstancia();
    }

    // Devuelve el id_pedido generado por MySQL, o -1 si falla
    public int guardarPedido(String idCliente, String metodoPago, double total) {
        String sql = "INSERT INTO pedidos (id_cliente, id_empleado, metodo_pago, estado, total) "
                   + "VALUES (?, NULL, ?, 'Pendiente', ?)";
        try {
            Connection cn = con.conectar();
            PreparedStatement ps = cn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            ps.setString(1, idCliente);
            ps.setString(2, metodoPago);
            ps.setDouble(3, total);

            if (ps.executeUpdate() > 0) {
                ResultSet rs = ps.getGeneratedKeys();
                if (rs.next()) {
                    return rs.getInt(1);
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al guardar pedido: " + e.getMessage());
        } finally {
            con.desconectar();
        }
        return -1;
    }
}