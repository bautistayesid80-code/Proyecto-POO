/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import BASEDATOS.Conexion;
import ENTIDADES.Facturas;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.ResultSet;


public class FacturaDAO {

    public String generarSiguienteNumeroFactura() {
        String siguienteNumero = "MKP-FAC-0001";
        String sql = "SELECT numero_factura FROM facturas ORDER BY id_factura DESC LIMIT 1";

        Conexion conexion = new Conexion();
        Connection cn = conexion.conectar();

        if (cn == null) {
            return siguienteNumero;
        }

        try (PreparedStatement ps = cn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            if (rs.next()) {
                String ultimoNumero = rs.getString("numero_factura");
                if (ultimoNumero != null && ultimoNumero.contains("-")) {
                    String[] partes = ultimoNumero.split("-");
                    int consecutivo = Integer.parseInt(partes[partes.length - 1]);
                    consecutivo++;
                    siguienteNumero = String.format("MKP-FAC-%04d", consecutivo);
                }
            }
        } catch (Exception ex) {
            System.err.println("Error al calcular el consecutivo de factura: " + ex.getMessage());
        } finally {
            try {
                if (cn != null && !cn.isClosed()) {
                    cn.close();
                }
            } catch (SQLException e) {
                System.err.println("Error al cerrar conexion: " + e.getMessage());
            }
            conexion.desconectar();
        }

        return siguienteNumero;
    }

  public boolean guardarFactura(Facturas f) {
        Conexion conexion = new Conexion();
        Connection cn = conexion.conectar();

        if (cn == null) {
            System.err.println("Error: No se pudo conectar a la base de datos.");
            return false;
        }

        // 1. Inserción en pedidos (id_cliente en pedidos es int(11) según la estructura de pedidos)
        String sqlPedido = "INSERT INTO pedidos (id_cliente, id_empleado, fecha_hora, metodo_pago, estado, total) "
                         + "VALUES (?, ?, NOW(), ?, ?, ?)";

        // 2. Inserción en facturas (id_cliente es varchar(36) coincidiendo con users.id)
        String sqlFactura = "INSERT INTO facturas ("
                          + "numero_factura, id_pedido, id_cliente, id_empleado, fecha_emision, "
                          + "subtotal, impuestos, total, metodo_pago, estado_factura, codigo_comercio, nombre_comercial) "
                          + "VALUES (?, ?, ?, ?, NOW(), ?, ?, ?, ?, 'emitida', ?, ?)";

        try {
            cn.setAutoCommit(false); // Iniciar transacción

            // Paso 0: Obtener el UUID real de la tabla users
            String idUsuarioUUID = f.getUserId();
            String sqlBuscarUUID = "SELECT id FROM users WHERE email = ? LIMIT 1";

            // Intentar buscar por el correo cargado en la factura
            try (PreparedStatement psUser = cn.prepareStatement(sqlBuscarUUID)) {
                psUser.setString(1, f.getEmailUsuario());
                try (ResultSet rsUser = psUser.executeQuery()) {
                    if (rsUser.next()) {
                        idUsuarioUUID = rsUser.getString("id");
                    }
                }
            }

            // Si no encontró por email o viene vacío, tomar el primer usuario registrado en la base de datos
            if (idUsuarioUUID == null || idUsuarioUUID.trim().isEmpty() || idUsuarioUUID.equalsIgnoreCase("Sin registrar") || idUsuarioUUID.length() < 10) {
                String sqlPrimerUser = "SELECT id FROM users LIMIT 1";
                try (PreparedStatement psPrimer = cn.prepareStatement(sqlPrimerUser);
                     ResultSet rsPrimer = psPrimer.executeQuery()) {
                    if (rsPrimer.next()) {
                        idUsuarioUUID = rsPrimer.getString("id");
                    } else {
                        // Respaldo de emergencia si la tabla users no tuviera filas
                        idUsuarioUUID = java.util.UUID.randomUUID().toString();
                        String sqlCrear = "INSERT INTO users (id, email, password_hash, first_name, last_name, role) "
                                        + "VALUES (?, 'cliente@mokpo.com', '123456', 'Cliente', 'Mokpo', 'customer')";
                        try (PreparedStatement psCrear = cn.prepareStatement(sqlCrear)) {
                            psCrear.setString(1, idUsuarioUUID);
                            psCrear.executeUpdate();
                        }
                    }
                }
            }

            int nuevoIdPedido = 0;

            // Paso A: Guardar en pedidos (usa id_cliente numérico para la tabla pedidos)
            try (PreparedStatement psPedido = cn.prepareStatement(sqlPedido, java.sql.Statement.RETURN_GENERATED_KEYS)) {
                psPedido.setInt(1, 1); // ID numérico de cliente en pedidos
                psPedido.setInt(2, 1); // ID numérico de empleado
                psPedido.setString(3, f.getMetodoPago());
                psPedido.setString(4, "PAGADO");
                psPedido.setDouble(5, f.getTotal());
                psPedido.executeUpdate();

                try (ResultSet rs = psPedido.getGeneratedKeys()) {
                    if (rs.next()) {
                        nuevoIdPedido = rs.getInt(1);
                    }
                }
            }

            // Paso B: Guardar en facturas vinculando el nuevo id_pedido y el id_cliente (UUID)
            try (PreparedStatement psFactura = cn.prepareStatement(sqlFactura)) {
                psFactura.setString(1, f.getNumeroFactura());
                psFactura.setInt(2, nuevoIdPedido);
                psFactura.setString(3, idUsuarioUUID);           // UUID válido de la tabla users
                psFactura.setInt(4, 1);
                psFactura.setDouble(5, f.getSubtotal());
                psFactura.setDouble(6, f.getIva());              // impuestos
                psFactura.setDouble(7, f.getTotal());
                psFactura.setString(8, f.getMetodoPago());
                psFactura.setString(9, f.getCodigoComercio());
                psFactura.setString(10, f.getNombreComercial());
                psFactura.executeUpdate();
            }

            cn.commit(); // Confirmar ambas tablas
            return true;

        } catch (SQLException ex) {
            System.err.println("Error en transacción pedido/factura: " + ex.getMessage());
            try {
                cn.rollback();
            } catch (SQLException rollbackEx) {
                System.err.println("Error en rollback: " + rollbackEx.getMessage());
            }
            return false;

        } finally {
            try {
                cn.setAutoCommit(true);
            } catch (SQLException e) {
                System.err.println("Error al restaurar autoCommit: " + e.getMessage());
            }
            conexion.desconectar();
        }
    }}