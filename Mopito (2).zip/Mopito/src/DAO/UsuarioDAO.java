/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import BASEDATOS.Conexion;
import ENTIDADES.Usuario;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.UUID;

public class UsuarioDAO {

    private final Conexion con;

    public UsuarioDAO() {
        this.con = Conexion.getInstancia();
    }

    // 1. Iniciar sesión validando correo y contraseña en la tabla 'users'
    public Usuario validarCredenciales(String correo, String password) {
        Usuario usuario = null;
     String sql = "SELECT id, first_name, last_name, email, phone, created_at FROM users WHERE email = ? AND password_hash = ? AND is_active = 1";
        Connection cn = null;

        try {
            cn = con.conectar();
            PreparedStatement ps = cn.prepareStatement(sql);
            ps.setString(1, correo);
            ps.setString(2, password);

            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                usuario = new Usuario();
                usuario.setId(rs.getString("id"));
                usuario.setNombre(rs.getString("first_name") + " " + rs.getString("last_name"));
                usuario.setCorreo(rs.getString("email"));
                usuario.setTelefono(rs.getString("phone") != null ? rs.getString("phone") : "Sin registrar");
                usuario.setFechaRegistro(rs.getString("created_at"));
            }
        } catch (SQLException e) {
            System.err.println("Error al validar credenciales: " + e.getMessage());
        } finally {
            con.desconectar();
        }
        return usuario;
    }

    // 2. Insertar nuevo usuario en la tabla 'users'
    public boolean registrarUsuario(Usuario usuario) {
        // Separamos el nombre completo ingresado en first_name y last_name
        String nombreCompleto = usuario.getNombre().trim();
        String firstName = nombreCompleto;
        String lastName = "."; // Valor por defecto si solo escribió un nombre

        if (nombreCompleto.contains(" ")) {
            int espacio = nombreCompleto.indexOf(" ");
            firstName = nombreCompleto.substring(0, espacio);
            lastName = nombreCompleto.substring(espacio + 1);
        }

        // Generamos un UUID para el campo id (varchar(36))
        String idGenerado = UUID.randomUUID().toString();

        String sql = "INSERT INTO users (id, email, password_hash, first_name, last_name, role, is_active) "
                + "VALUES (?, ?, ?, ?, ?, 'customer', 1)";
        Connection cn = null;

        try {
            cn = con.conectar();
            PreparedStatement ps = cn.prepareStatement(sql);
            ps.setString(1, idGenerado);
            ps.setString(2, usuario.getCorreo());
            ps.setString(3, usuario.getPassword());
            ps.setString(4, firstName);
            ps.setString(5, lastName);

            int filasAfectadas = ps.executeUpdate();
            return filasAfectadas > 0;

        } catch (SQLException e) {
            System.err.println("Error al registrar usuario: " + e.getMessage());
            return false;
        } finally {
            con.desconectar();
        }
    }

    // 3. Verificar si el correo ya existe en 'users'
    public boolean existeCorreo(String correo) {
        String sql = "SELECT id FROM users WHERE email = ?";
        Connection cn = null;

        try {
            cn = con.conectar();
            PreparedStatement ps = cn.prepareStatement(sql);
            ps.setString(1, correo);

            ResultSet rs = ps.executeQuery();
            return rs.next();

        } catch (SQLException e) {
            System.err.println("Error al verificar correo: " + e.getMessage());
            return false;
        } finally {
            con.desconectar();
        }
    }
}
